export { MenusPage, menusRouteLoader } from './MenusPage';
